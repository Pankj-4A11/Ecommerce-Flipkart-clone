


const NotFound = () => {
    return (
        <p>Not Found! 404</p>
    )
}

export default NotFound;